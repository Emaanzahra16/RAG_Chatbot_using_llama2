from setuptools import find_packages, setup
setup(
    name="AI ChatBot",
    version="0.0.0",
    author="Hafsa Rafique",
    author_email="rafiquehafsa456@gmail.com",
    packages=find_packages(), #find _init_.py file, makes that folder as local package
    install_requires=[]

)